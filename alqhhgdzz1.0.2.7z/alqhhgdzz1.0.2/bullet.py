# 安粮期货股份有限公司 信息技术部 软件开发小组 - jawa 2018.06.05

import pygame
import os

current_path = os.path.dirname(__file__)                  # .py 文件位置
# resource_path = os.path.join(current_path, 'resources') # resource 目录路径
image_path = os.path.join(current_path, 'images')         # image 目录路径
sound_path = os.path.join(current_path, 'sound')          # sound 目录路径
font_path = os.path.join(current_path, 'font')            # font  目录路径


class Bullet1(pygame.sprite.Sprite):
    def __init__(self, position):
        pygame.sprite.Sprite.__init__(self)

        self.image = pygame.image.load(os.path.join(image_path,'bullet1.png')).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = position
        self.speed = 12
        self.active = False
        self.mask = pygame.mask.from_surface(self.image)

    def move(self):
        self.rect.top -= self.speed

        if self.rect.top < 0:
            self.active = False

    def reset(self, position):
        self.rect.left, self.rect.top = position
        self.active = True

class Bullet2(pygame.sprite.Sprite):
    def __init__(self, position):
        pygame.sprite.Sprite.__init__(self)

        self.image = pygame.image.load(os.path.join(image_path,'bullet2.png')).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = position
        self.speed = 14
        self.active = False
        self.mask = pygame.mask.from_surface(self.image)

    def move(self):
        self.rect.top -= self.speed

        if self.rect.top < 0:
            self.active = False

    def reset(self, position):
        self.rect.left, self.rect.top = position
        self.active = True
    
